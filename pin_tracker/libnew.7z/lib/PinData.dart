import 'dart:math';

import 'package:flutter/material.dart';
import 'package:pin_tracker/SetDetailsView.dart';
import 'Objects.dart';
import 'package:sqflite/sqflite.dart';
import 'package:pin_tracker/db_helper.dart';


class SetListView extends State{
  List<PinSet> sets;
  List<Pin> pins;
  Drawer _drawer;
  int owned;
  int marked;
  DataTable _dataTable;
  SetListView(this.sets,this.pins,this._drawer);

  @override
  void initState() {


    super.initState();
  }

  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text("Data", style: Theme.of(context).textTheme.title,),

      ),
      drawer: _drawer,
      backgroundColor: Colors.white,
      body: _buildData(),
    );
  }

}

Widget _buildData(){

  return Container();
}

class PinData extends StatefulWidget{
  List<PinSet> sets;
  List<Pin> pins;
  Drawer _drawer;
  PinData(this.sets, this.pins, this._drawer);

  @override
  SetListView createState() => SetListView(this.sets, this.pins, this._drawer);
}