// Copyright 2018 The Flutter team. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/material.dart' as prefix0;
import 'package:sqflite/sqflite.dart';
import 'package:flutter_app/db_helper.dart';
import 'package:expandable/expandable.dart';


void main() => runApp(MyApp());

class PinSet{
  int year;
  int wave;
  int series;
  String img;
  PinSet(this.img, this.year, this.wave, this.series);

  String toString(){
    return "Year: " + year.toString() + ", series: " + series.toString() + ", img: " + img;
  }
}

class Pin{
  int id;
  String img;
  int quantity;
  bool has = false;
  Pin(this.id, this.img, this.quantity){
    if (quantity == 0)
      has = false;
    else
      has = true;
  }
  bool have(){
    if (quantity == 0){
      return false;
    }
    else{
      return true;
    }
  }
}





class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      title: 'Pins',
      home: PinsList(),

    );
  }
}

class SortStatus{
  static int state;
  final ASCENDING = 1;
  final DESCENDING = 2;
  List<int> states = [0, 1, 2];
  Map<int, String> state_desc = {0:"Sort y", 1:"Oldest First", 2:"Newest First"};
  Map<int, bool> activeYears = {2006: true, 2007: true, 2008: true};
  SortStatus(){
    state = 2;
  }
  set(state){
    SortStatus.state = state;
  }
  activate(y){
    activeYears[y] = true;
  }
  deactivate(y){
    activeYears[y] = false;
  }
  bool isActive(y){
    return activeYears[y];
  }
}

class SettingsState extends State{

  PinsListState pls;
  SettingsState(this.pls);
  @override
  Widget build(BuildContext context) {
    print(pls._status.state_desc[1]);


    return Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[Container(
                color: Colors.indigo,
                width: MediaQuery.of(context).size.width,
                height:  MediaQuery.of(context).size.height / 9,
                margin: EdgeInsets.only(bottom: 8),
              )],
            ),
            Row(

              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text("Pin Sets are displayed:"),
                  Container(
                    child: DropdownButton<int>(
                      items: [
                        DropdownMenuItem(
                          value: 0,
                          child: Text(""),
                        ),
                        DropdownMenuItem(
                          value: 1,
                          child: Text("Oldest First"),
                        ),
                        DropdownMenuItem(
                          value: 2,
                          child: Text("Newest First"),
                        ),
                      ],
                      onChanged: (value) {
                        setState(() {
                          SortStatus.state = value;

                        });
                      },
                      value: SortStatus.state,

                    ),
                    color: Colors.black26,
                    margin: EdgeInsets.symmetric(vertical: 10, horizontal: 6),
                    alignment: Alignment.topCenter,
                    width: MediaQuery.of(context).size.width * 0.4,

                  ),


              ],
            ),/* new Row(
              children: <Widget>[
              ],
            ),
            new Row(
              children: <Widget>[
              ],
            ),
            new Row(
              children: <Widget>[
              ],
            ),
*/
          ],
        )

    );
  }


}

class PinsListState extends State {

  final dbHelper = DatabaseHelper.instance;

  SortStatus _status = SortStatus();
  bool displayYears = false;
  List<PinSet> pinList;
  int st = SortStatus.state;
  @override
  Widget build(BuildContext context) {

    if (pinList == null){
      //DatabaseHelper.instance.forceRefresh();

      pinList = new List<PinSet>();
      updateList();
    }




    return Scaffold(
      appBar: AppBar(
          title: Text('Disney Pins'),
          actions: <Widget>[
          // action button
            IconButton(
            icon: Icon(Icons.check_circle),
            onPressed: () {
              updateList();
              setState(() {
              print(SortStatus.state.toString() + "           state");
              });
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return Settings(this);
              }));
            },
                ),
            ],
          ),
      body: _buildPins()

    );

  }



  // CANT MAKE LIST FROM DB BECAUSE IT IS TOO SLOW AND DOESNT INIT IN TIME
  void updateList() {
    //*
    //pinList.clear();
    print(_getInfo(2));
    List<PinSet> newSets = [];
    Future<List<Map<String, dynamic>>> temp = DatabaseHelper.instance.getSets();
    temp.then((newList) {
      if (SortStatus.state == _status.DESCENDING){
        Map<int, int> year = {2020:0, 2019:1, 2018:2, 2017:3, 2016:4, 2015:5, 2014:6, 2013:7, 2012:8, 2011:9, 2010:10, 2009:11, 2008:12, 2007:13, 2006:14, 2005:15};
        List< List<int>> buckets = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []];
        //[{2020:[]}, {2019:[]}, {2018:[]}, {2017:[]}, {2016:[]}, {2015:[]}, {2014:[]}, {2013:[]}, {2012:[]}, {2011:[]}, {2010:[]}, {2009:[]}, {2008:[]}, {2007:[]}, {2006:[]}, {2005:[]} ];
        for (var i = 0; i < newList.length; i++){
          buckets[year[newList[i]["Year"]]].add(i);
          print(buckets);
          //print(newList[i]["Year"].toString() + "  " + i.toString());
        }
        for (var year_col = 0; year_col < buckets.length; year_col++){
          if (buckets[year_col].length > 0){
            newSets.add(PinSet(newList[buckets[year_col][0]]["Year"].toString() + " Pins", newList[buckets[year_col][0]]["Year"], 0, 0));
          }
          for (var itr = 0; itr < buckets[year_col].length; itr++){
            print("bucket " + year_col.toString() + ", " + itr.toString() + " === " + buckets[year_col][itr].toString());
            newSets.add(PinSet(newList[buckets[year_col][itr]]["Year"].toString() + "/" + newList[buckets[year_col][itr]]["Year"].toString() + "_" + newList[buckets[year_col][itr]]["Series"].toString() + "_full.png", newList[buckets[year_col][itr]]["Year"], newList[buckets[year_col][itr]]["Wave"], newList[buckets[year_col][itr]]["Series"]));
          }
        }
        buckets.clear();
        pinList.clear();
        pinList.addAll(newSets);
      }
      else if (SortStatus.state == _status.ASCENDING){
        List<int> hit_years = [];
        for(var row in newList){
          if (!hit_years.contains(row["Year"])){
            hit_years.add(row["Year"]);
            newSets.add(PinSet(row["Year"].toString() + " Pins", row["Year"], 0, 0));
          }
          String p = row["Year"].toString() + "/" + row["Year"].toString() + "_" + row["Series"].toString() + "_full.png";
          newSets.add(PinSet(p, row["Year"], row["Wave"], row["Series"]));
        }
        print(_status.activeYears.toString());
        pinList.clear();
        pinList.addAll(newSets);
      }

    });



  }
  
  Widget _buildPins() {
    print("BUILDING");
    return ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 2),
        itemCount: pinList.length,
        itemBuilder: /*1*/ (context, i) {
          return _buildRow(pinList[i]);
        });



  }

  Widget _buildRow(PinSet set) {
    if (set.series == 0){
      Color bg = Color.fromRGBO(90, 90, 90, 1);
      return Container(
        //alignment: Alignment.topLeft,
        margin: EdgeInsets.only(bottom: 1),
        height: 46,
        //color: Colors.grey,
        decoration: new BoxDecoration(
            border: Border.all(color: Colors.black, width: 3),
          color: ((_status.isActive(set.year)) ? (Colors.grey) : (bg)),

        ),
        child: ListTile(

          title: new Row(children: <Widget>[new Text(set.img,
            style: new TextStyle(
                fontWeight: FontWeight.w500, fontSize: 25.0,
            ),)
          ],
            //mainAxisAlignment: MainAxisAlignment.start,
          ),


          onTap: (){
            if (_status.isActive(set.year))
              _status.deactivate(set.year);
            else
              _status.activate(set.year);
            updateList();
            setState(() {

            });
          },
        ),alignment: Alignment(-1.0, -1.0),

        //padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),

      );
    }
    else if (!_status.isActive(set.year)){
      return Container(
        width: 0,
        height: 0,
        color: Colors.red,
        child: Text("NOPE"),
      );
    }
    return Container(

        alignment: Alignment.centerLeft,
        color: Color.fromRGBO(98, 98, 90, 0),
        child: ListTile(
      title: Image.asset('assets/${set.img}'),
      //title: Text(
      //    set.name
      //),
      //trailing: Image.asset('assets/${set.img}'),
      //trailing: Text(   set.img,
      //),                // ... to here.
      onTap: () {      // Add 9 lines from here...
        setState(() {
          _pushSelect(set);
        });
      },
    )
    );
  }


  void _pushSelect(PinSet set) async{
    List<Pin> list = await _getSet(set.year, set.wave, set.series);
    int id = 0;
    if (list.length > 0)
      id = list[0].id;
    else
      print("---------\nList of pins has no elements\n========\n");
    List<Pin> temp = await DatabaseHelper.instance.checkForRelevantPins(id);
    String i = "";
    Map<String, dynamic> setinfo = new Map<String, dynamic>();
    setinfo.addAll(await DatabaseHelper.instance.getSetInfo(id));
    if (temp.isEmpty)
      i = _getInfo(id);
    else
      i = "Here are some similar pins";
    Navigator.push(context, MaterialPageRoute(builder: (context) {
      return PinsDetail(list, setinfo["Description"], temp, i);
    }));

  }
}



class PinDetailsState extends State<PinsDetail>  {
  final dbHelper = DatabaseHelper.instance;
  List<Pin> list;
  String title;
  String exitinfo = "End";
  PinDetailsState(this.list, this.title);

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        appBar: AppBar(
        title: Text(title),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[Container(
                color: Colors.indigo,
                child: Text(title),
                width: MediaQuery.of(context).size.width,
                height:  10,
              )],
            ),
            Expanded(child: _buildSet(list)),


            /* new Row(
              children: <Widget>[
              ],
            ),
            new Row(
              children: <Widget>[
              ],
            ),
*/
          ],
        )

    );
  }

  Widget _buildSet(List<Pin> list) {
    return ListView.builder(
        itemCount: list.length+ 2 + widget.list2.length,
        itemBuilder: /*1*/ (context, i) {

          if ((i == list.length) || (i >=list.length+ 1 + widget.list2.length)){
            return Container(
              color: Colors.blueAccent,
              height: 120,
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: Text(((i == list.length)?(widget.info.toString()):(widget.exitinfo.toString())),
                style: TextStyle(
                  fontSize: 26.0,
                  color: Colors.white,

                ),
              ),
              alignment: Alignment.center,
            );//_buildDetails(list[i]);
          }
            if (i > list.length){
              return Container(
                color: Color.fromRGBO(98, 98, 90, .2),
                height: 120, alignment: Alignment.topCenter,
                  margin: EdgeInsets.only(bottom: 2, top: 2),
                child: Row(

                 children: <Widget>[
                    Container(
                      color: Color.fromRGBO(200, 200, 200, .8),
                      height: 120,
                      child: _buildDetailsSmall(widget.list2[i- list.length-1]),
                      alignment: Alignment.centerLeft,
                      width: MediaQuery.of(context).size.width *.41,


                    ),

                   Expanded(child: Container(
                     color: Color.fromRGBO(200, 200, 200, .8),
                     child: Text(_getInfo(widget.list2[i-list.length - 1].id).toString(),
          style: TextStyle(
          fontSize: 26.0,
          color: Colors.black,),),


                     alignment: Alignment.center,
                   )
                   ),
                   new Container(
                     color: Color.fromRGBO(9, 9, 9, .2),
                     child: Checkbox(
                       value: widget.list2[i- list.length-1].has,
                       onChanged: (val) {
                         setState(() {
                           widget.list2[i- list.length-1].has = val;
                           if (widget.list2[i- list.length-1].has)
                             DatabaseHelper.instance.update({"ID" : widget.list2[i- list.length-1].id, "Qty" : 1});
                           else
                             DatabaseHelper.instance.update({"ID" : widget.list2[i- list.length-1].id, "Qty" : 0});
                         });

                       },
                     ),

                     alignment: Alignment.centerLeft,
                     width: 60,
                   ),
                 ],

                )
              );//_buildDetails(list[i]);
            }
              // i == list.len





          // when i < list.length
            return Container(
              color: Color.fromRGBO(98, 98, 90, .2),
              height: 120,
              child: _buildDetails(list[i]),
              alignment: Alignment.topCenter,
              margin: EdgeInsets.only(bottom: 2, top: 2),
            );//_buildDetails(list[i]);

  });
  }

  Widget _buildDetails(Pin pin) {
    return ListTile(
      //title: Image.asset('assets/${pin.img}'),
      contentPadding: EdgeInsets.symmetric(horizontal: 70, vertical: 8),
      trailing: Checkbox(
        value: pin.has,
        onChanged: (val) {
          setState(() {
            pin.has = val;
            if (pin.has)
              DatabaseHelper.instance.update({"ID" : pin.id, "Qty" : 1});
            else
              DatabaseHelper.instance.update({"ID" : pin.id, "Qty" : 0});
          });

        },
      ),
      title: Container(
        //color: Colors.deepOrange,
        width: 180,
        child: Image.asset('assets/${pin.img}'),
        alignment: Alignment.topCenter,
      ),

      /*trailing: Checkbox(
        value: pin.has,
        onChanged: (val) {
          setState(() {
            pin.has = val;
            print("CHECK");
            if (pin.has)
              DatabaseHelper.instance.update({"ID" : pin.id, "Qty" : 1});
            else
              DatabaseHelper.instance.update({"ID" : pin.id, "Qty" : 0});
          });

        },
      ),*/
    );
  }

  Widget _buildDetailsSmall(Pin pin) {
    return ListTile(
      //title: Image.asset('assets/${pin.img}'),

      title: Container(
        //color: Colors.deepOrange,
        width: 120,
        child: Image.asset('assets/${pin.img}'),
        alignment: Alignment.center,
      ),

      /*trailing: Checkbox(
        value: pin.has,
        onChanged: (val) {
          setState(() {
            pin.has = val;
            print("CHECK");
            if (pin.has)
              DatabaseHelper.instance.update({"ID" : pin.id, "Qty" : 1});
            else
              DatabaseHelper.instance.update({"ID" : pin.id, "Qty" : 0});
          });

        },
      ),*/
    );
  }

}

String _getInfo(int id){
  String s = "";
  Future<Map<String, dynamic>> setinfo = DatabaseHelper.instance.getSetInfo(id);
  setinfo.then((i){
    s = i["Year"].toString() + "\nWave " + String.fromCharCode(i["Wave"] + 64) + " \nSet " + i["Series"].toString() + "\n" + ((i["Description"].toString().contains("CMP")) ? ("Completer Pins") : (i["Description"].toString()));
    return s;
  });
return"a";
}



class Settings extends StatefulWidget {
  PinsListState plstate;
  Settings(this.plstate);
  @override
  SettingsState createState() => SettingsState(plstate);
}

class PinsList extends StatefulWidget {
  @override
  PinsListState createState() => PinsListState();
}

class PinsDetail extends StatefulWidget {

  List<Pin> list;
  String title;
  List<Pin> list2;
  String info;
  String exitinfo = "That is the end";

  PinsDetail(this.list, this.title, this.list2, this.info);

  @override
  State<StatefulWidget> createState() {
    exitinfo = "That is the end";

    return PinDetailsState(this.list, this.title);
  }
}





Future<List<Pin>> _getSet(int year, int wave, int set) async {
  print("QUERY...");
  List<Pin> list = [];
  List<Map> result = await DatabaseHelper.instance.getSet(year, wave, set, ["ID", "Path", "Qty"]);
  result.forEach((row) => list.add(Pin(row["ID"], year.toString() +'/'+ row["Path"], row["Qty"])));
  list.forEach((r) => print(r.img));
  return list;
  //print(result);

}
void _listDB() async {
  print("QUERY...");
  List<Map> result = await DatabaseHelper.instance.getSet(2006, 1, 1, ["Path", "Qty"]);
  result.forEach((row) => print(row));
  //print(result);

}