

import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:typed_data';
import 'main.dart';

class DatabaseHelper {

  static final _databaseName = "Pins.db";
  static final _databaseVersion = 1;

  static final table = 'Pins';

  static final columnId = 'ID';
  static final columnYear = 'Year';
  static final columnWave = 'Wave';
  static final columnSeries = 'Series';
  static final columnNumber = 'Number';
  static final columnQty = 'Qty';
  static final columnDesc = 'Description';
  static final columnPath = 'Path';

  // make this a singleton class
  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  // only have a single app-wide reference to the database
  static Database _database;
  Future<Database> get database async {
    if (_database != null) return _database;
    // lazily instantiate the db the first time it is accessed
    _database = await _initDatabase();
    return _database;
  }

  // this opens the database (and creates it if it doesn't exist)
  _initDatabase() async {
    //Directory documentsDirectory = await getApplicationDocumentsDirectory();
    //String path = join(documentsDirectory.path, _databaseName);
    //return await openDatabase(path,
      //  version: _databaseVersion,
     //   onCreate: _onCreate);


    var databasesPath = await getDatabasesPath();
    var path = join(databasesPath, "Pins.db");

// Check if the database exists
    var exists = await databaseExists(path);

    if (!exists) {
      // Should happen only the first time you launch your application
      print("Creating new copy from asset");

      // Make sure the parent directory exists
      try {
        await Directory(dirname(path)).create(recursive: true);
      } catch (_) {}

      // Copy from asset
      ByteData data = await rootBundle.load(join("assets", "Pins.db"));
      List<int> bytes =
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);

      // Write and flush the bytes written
      await File(path).writeAsBytes(bytes, flush: true);

    } else {
      print("Opening existing database");
    }
// open the database
    return await openDatabase(path, readOnly: false);

  }

  // SQL code to create the database table
  Future _onCreate(Database db, int version) async {
    /*await db.execute('''
          CREATE TABLE $table (
            $columnId INTEGER PRIMARY KEY,
            $columnName TEXT NOT NULL,
            $columnAge INTEGER NOT NULL
          )
          ''');

     */
  }

  // Helper methods

  void forceRefresh() async{
    var databasesPath = await getDatabasesPath();
    var path = join(databasesPath, "Pins.db");
    print("Updating Phone DB with asset DB");

    // Make sure the parent directory exists
    try {
      await Directory(dirname(path)).create(recursive: true);
    } catch (_) {}

    // Copy from asset
    ByteData data = await rootBundle.load(join("assets", "Pins.db"));
    List<int> bytes =
    data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);

    // Write and flush the bytes written
    await File(path).writeAsBytes(bytes, flush: true);
  }

  // Inserts a row in the database where each key in the Map is a column name
  // and the value is the column value. The return value is the id of the
  // inserted row.
  Future<int> insert(Map<String, dynamic> row) async {
    Database db = await instance.database;
    return await db.insert(table, row);
  }

  // All of the rows are returned as a list of maps, where each map is
  // a key-value list of columns.
  Future<List<Map<String, dynamic>>> queryAllRows() async {
    Database db = await instance.database;
    List<Map<String, dynamic>> l = await db.query(table);
    //l.forEach((row) => print(row));
    return await db.query(table);
  }

  Future<List<Map<String, dynamic>>> getSet(int year,int wave, int set, List<String> returnCols) async {
    Database db = await instance.database;
    /*List<String> columnsToSelect = [
      DatabaseHelper.columnNumber,
      DatabaseHelper.columnQty,
      DatabaseHelper.columnPath
    ];*/
    String whereString = '${DatabaseHelper.columnYear} = ? AND ${DatabaseHelper.columnWave} = ? AND ${DatabaseHelper.columnSeries} = ?';
    List<dynamic> whereArguments = [year, wave, set];
    List<Map> result = await db.query(
        DatabaseHelper.table,
        columns: returnCols,
        where: whereString,
        whereArgs: whereArguments);
    // print the results

    return result;
  }

  Future<Map<String, dynamic>> getSetInfo(int id) async{
    Database db = await instance.database;
    List<Map<String, dynamic>> info = new List<Map<String, dynamic>>() ;
    info.addAll(await db.rawQuery('SELECT Year, Series, Wave, $columnDesc  FROM $table WHERE $columnId = ?',[id]));
    return info.first;
  }

  Future<List<Map<String, dynamic>>> getSets() async{
    Database db = await instance.database;
    String whereString = '${DatabaseHelper.columnNumber} = ?';
    List<Map> result = await db.query(
        DatabaseHelper.table,
        columns: ["Year", "Wave", "Series"],
        where: whereString,
        whereArgs: [1]);

    return result;
  }

  // All of the methods (insert, query, update, delete) can also be done using
  // raw SQL commands. This method uses a raw query to give the row count.
  Future<int> queryRowCount() async {
    Database db = await instance.database;
    return Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM $table'));
  }

  // We are assuming here that the id column in the map is set. The other
  // column values will be used to update the row.
  Future<int> update(Map<String, dynamic> row) async {
    Database db = await instance.database;
    int id = row[columnId];
    return await db.update(table, row, where: '$columnId = ?', whereArgs: [id]);
  }

  Future<List<Pin>> checkForRelevantPins(int id)async{
    Database db = await instance.database;
    List<Map<String, dynamic>> hits = List();
    hits.addAll(await db.rawQuery('SELECT $columnDesc, Series, Year FROM $table WHERE $columnId = ?',[id]));
    String desc = hits.first["Description"];
    String newdesc = "CMP " + hits.first["Description"];
    int s = hits.first["Series"];
    int y = hits.first["Year"];
    List<Map<String, dynamic>> result = List();
    result.addAll(await db.rawQuery('SELECT ID, Year, Path FROM $table WHERE $columnDesc = ? AND Series != ?',['$newdesc', '$s']));
    hits.clear();
    hits.addAll(await db.rawQuery('SELECT ID, Year, Series, Number, Qty, Path FROM $table WHERE $columnDesc = ? AND Year != ?',['$desc', '$y']));

    result.addAll(hits);
    List<Pin> pins= new List();
    result.forEach((p) => pins.add(Pin(p["ID"], p["Year"].toString() + "/" + p["Path"],p["Qty"] )));
    return pins;
  }

  // Deletes the row specified by the id. The number of affected rows is
  // returned. This should be 1 as long as the row exists.
  Future<int> delete(int id) async {
    Database db = await instance.database;
    return await db.delete(table, where: '$columnId = ?', whereArgs: [id]);
  }

  Future<String> getDescription(int id) async{
    Database db = await instance.database;
    List<Map> result = await db.query(
      DatabaseHelper.table,
      columns: [DatabaseHelper.columnDesc],
      where: '${DatabaseHelper.columnId} = ?',
      whereArgs: [id]
    );
    print(result);
    if (result.length == 0)
      return "LENGTH WAS ZERO";
    return result.first["Description"];
  }
}